# Guía de Integración y Configuración para Freight Forwarder Pro

Este documento detalla los pasos necesarios para integrar y configurar los scripts proporcionados en su proyecto Unity 6, asegurando un sistema de mapa 3D, tiempo e iluminación solar realista y funcional.

## 1. Estructura del Proyecto

Para una organización óptima, se recomienda la siguiente estructura de carpetas en su proyecto Unity:

```
Assets/
├── Art/
│   └── Map/
│       └── Resources/
│           └── Map/
│               └── Textures/ (Aquí deben ir 01.jpg a 12.jpg)
├── Materials/
├── Prefabs/
├── Scenes/
├── Scripts/
│   ├── CityMarker.cs
│   ├── GameBootstrapper.cs
│   ├── MapCameraController.cs
│   ├── SunController.cs
│   ├── TimeManager.cs
│   └── WorldMap.cs
└── UI/
```

**Scripts:** Coloque todos los archivos `.cs` proporcionados en la carpeta `Assets/Scripts/`.

**Texturas:** Las texturas mensuales de la Tierra (`01.jpg` a `12.jpg`) deben ubicarse en `Assets/Art/Map/Resources/Map/Textures/`. Es crucial que estén dentro de una carpeta `Resources` para que `WorldMap.cs` pueda cargarlas dinámicamente.

## 2. Configuración de la Escena

Cree una nueva escena o utilice una existente y configure los siguientes GameObjects:

### 2.1. GameObject `GameBootstrapper`

Este GameObject será el punto de entrada para la inicialización de los sistemas principales.

1.  Cree un GameObject vacío en la jerarquía (Clic derecho > Create Empty) y nómbrelo `GameBootstrapper`.
2.  Adjunte el script `GameBootstrapper.cs` a este GameObject.
3.  En el Inspector de `GameBootstrapper`, asigne las referencias a los otros scripts si ya existen en la escena. Si no, el `GameBootstrapper` intentará crearlos dinámicamente (ver sección 2.5).

### 2.2. GameObject `Earth` (Esfera del Mundo)

Representa el planeta Tierra.

1.  Cree una esfera 3D (Clic derecho > 3D Object > Sphere) y nómbrela `Earth`.
2.  Asegúrese de que su posición sea `(0, 0, 0)`.
3.  Adjunte el script `WorldMap.cs` a este GameObject.
4.  En el Inspector de `WorldMap`:
    *   **Earth Radius:** Establezca el radio deseado (ej. `10`). Este valor escalará la esfera y se usará para cálculos de coordenadas.
    *   **Earth Mesh Renderer:** Arrastre el componente `Mesh Renderer` de la esfera a este campo.
    *   **Textures Path:** Verifique que la ruta sea correcta (por defecto: `Map/Textures/`).

### 2.3. GameObject `Directional Light` (Sol)

Representa la fuente de luz solar.

1.  Asegúrese de tener una `Directional Light` en su escena (normalmente se crea por defecto en nuevas escenas). Si no, cree una (Clic derecho > Light > Directional Light) y nómbrela `Directional Light`.
2.  Adjunte el script `SunController.cs` a un GameObject vacío o al mismo `Directional Light`.
3.  En el Inspector de `SunController`:
    *   **Sun Light:** Arrastre el componente `Light` de su `Directional Light` a este campo.
    *   **Earth Transform:** Arrastre el GameObject `Earth` a este campo.
    *   **Earth Radius:** Asegúrese de que este valor coincida con el `Earth Radius` configurado en `WorldMap`.
    *   **Day Night Color:** Configure un `Gradient` que represente la transición de color del ambiente (ej. azul claro para el día, azul oscuro/negro para la noche).
    *   **Intensity Curve:** Configure una `Animation Curve` para controlar la intensidad de la luz solar a lo largo del día (ej. alta durante el día, cero durante la noche).

### 2.4. GameObject `Main Camera`

La cámara principal del juego con controles estilo Google Earth.

1.  Asegúrese de que su escena tenga una `Main Camera` (normalmente se crea por defecto). Si no, cree una (Clic derecho > Camera) y asegúrese de que su tag sea `MainCamera`.
2.  Adjunte el script `MapCameraController.cs` a este GameObject.
3.  En el Inspector de `MapCameraController`:
    *   **Earth Transform:** Arrastre el GameObject `Earth` a este campo.
    *   Configure los valores de `Initial Distance From Earth`, `Min Zoom Distance`, `Max Zoom Distance`, `Zoom Speed`, `Rotation Speed`, `Smooth Time` y `Focus Speed` según sus preferencias.

### 2.5. GameObject `UI Canvas`

Para mostrar la información de tiempo y velocidad.

1.  Cree un Canvas (Clic derecho > UI > Canvas).
2.  Dentro del Canvas, cree dos objetos `TextMeshPro - Text (UI)` (Clic derecho en Canvas > UI > Text - TextMeshPro). Si no tiene TextMeshPro importado, Unity le pedirá que lo haga.
    *   Nómbrelos `DateTimeText` y `SpeedText`.
    *   Ajuste sus posiciones y estilos para que sean visibles en la parte superior de la pantalla.
3.  Cree un GameObject vacío dentro del Canvas y nómbrelo `TimeControlsPanel`.
4.  Adjunte el script `UIManager.cs` a este `TimeControlsPanel`.
5.  En el Inspector de `UIManager`:
    *   **Date Time Text:** Arrastre el componente `TextMeshProUGUI` de `DateTimeText` a este campo.
    *   **Speed Text:** Arrastre el componente `TextMeshProUGUI` de `SpeedText` a este campo.
    *   **UI Hub Panel:** Arrastre el `Rect Transform` del `TimeControlsPanel` a este campo. El script se encargará de centrarlo.

### 2.6. City Markers

Para cada ciudad que desee marcar:

1.  Cree un GameObject vacío (o un prefab de marcador visual) y nómbrelo con el nombre de la ciudad (ej. `BuenosAiresMarker`).
2.  Adjunte el script `CityMarker.cs` a este GameObject.
3.  En el Inspector de `CityMarker`:
    *   **Latitude:** Ingrese la latitud real de la ciudad.
    *   **Longitude:** Ingrese la longitud real de la ciudad.
    *   **Surface Offset:** Un valor pequeño (ej. `0.01`) para que el marcador no se superponga con la superficie de la Tierra.
4.  Asegúrese de que el GameObject del marcador tenga un `Collider` (ej. `Sphere Collider` con `Is Trigger` activado) si desea que la cámara pueda enfocarlo al hacer clic.

## 3. Configuración de Materiales y Shaders

El script `WorldMap.cs` asigna la textura principal (`_MainTex`) del material de la esfera de la Tierra. Para transiciones suaves entre texturas mensuales, se recomienda un shader personalizado.

**Shader Recomendado (Concepto):**

Para una transición suave entre texturas mensuales, necesitará un shader que pueda mezclar dos texturas basándose en un valor de `blend` (0-1). Unity tiene shaders de ejemplo o puede crear uno con Shader Graph.

**Pasos para un Shader de Mezcla de Texturas (ejemplo con URP/HDRP Shader Graph):**

1.  Cree un nuevo Shader Graph (Clic derecho > Create > Shader Graph > URP/HDRP > Lit Shader Graph).
2.  Abra el Shader Graph y añada dos nodos `Sample Texture 2D`.
3.  Conecte los nodos `Texture 2D` a un nodo `Lerp` (Linear Interpolate).
4.  Exponga una propiedad `_Blend` (Float) y conéctela al puerto `T` del nodo `Lerp`.
5.  Conecte la salida del `Lerp` al puerto `Base Color` del `PBR Master`.
6.  Guarde el shader y cree un nuevo material (Clic derecho > Create > Material) usando este shader.
7.  Asigne este material al `Mesh Renderer` de su GameObject `Earth`.

**Ajustes en `WorldMap.cs` para el Shader:**

Si usa un shader de mezcla, necesitará modificar `UpdateEarthTexture` en `WorldMap.cs` para asignar las dos texturas y el valor de `_Blend` al material. Por ejemplo:

```csharp
// Dentro de UpdateEarthTexture
_earthMaterial.SetTexture("_Texture1", _monthlyTextures[currentMonthIndex]);
_earthMaterial.SetTexture("_Texture2", _monthlyTextures[nextMonthIndex]);
_earthMaterial.SetFloat("_Blend", dayOfMonthProgress); // dayOfMonthProgress sería el progreso del día en el mes
```

Actualmente, `WorldMap.cs` solo asigna `_MainTex`. Para usar un shader de mezcla, deberá adaptar el script para establecer las propiedades `_Texture1`, `_Texture2` y `_Blend` de su shader personalizado.

## 4. Configuración de la Luz Solar en Unity

La `Directional Light` en Unity representa una fuente de luz infinita, ideal para simular el sol. `SunController.cs` se encarga de su rotación.

1.  **Tipo de Luz:** Asegúrese de que el componente `Light` de su GameObject `Directional Light` sea de tipo `Directional`.
2.  **Modo de Renderizado:** Para un rendimiento óptimo y efectos de iluminación global, considere usar `Mixed` o `Realtime` para su `Directional Light`.
3.  **Sombras:** Configure las sombras según sea necesario (ej. `Soft Shadows` para un aspecto más realista).
4.  **Skybox:** Utilice un `Skybox` que cambie con el ciclo día/noche para complementar la iluminación. Puede usar un `Procedural Skybox` o uno personalizado que responda a la hora del día.

## 5. Orden de Inicialización (GameBootstrapper)

El script `GameBootstrapper.cs` está diseñado para asegurar que todos los componentes esenciales se inicialicen en el orden correcto. Se ejecuta en `Awake()` y `Start()`.

*   **Awake():** En esta fase, `GameBootstrapper` busca o crea instancias de `TimeManager`, `WorldMap`, `SunController`, `MapCameraController` y `UIManager`. Esto garantiza que los Singletons estén disponibles y que las referencias cruzadas se establezcan antes de que otros scripts intenten acceder a ellos.
*   **Start():** Después de que todos los `Awake()` se hayan completado, `GameBootstrapper` llama a métodos de inicialización específicos como `mapCameraController.InitializeCameraPosition()` para asegurar que la cámara se posicione correctamente una vez que `WorldMap` esté completamente configurado.

**Recomendación:** Coloque el script `GameBootstrapper.cs` en la configuración de Script Execution Order de Unity para que se ejecute antes que los demás scripts principales (`TimeManager`, `WorldMap`, etc.). Vaya a `Edit > Project Settings > Script Execution Order` y añada `GameBootstrapper` con un valor negativo (ej. `-100`).

## 6. Ajustes Adicionales

*   **Post-Processing:** Considere añadir un volumen de post-procesado a su escena para mejorar la calidad visual, incluyendo efectos como `Bloom`, `Color Grading` y `Ambient Occlusion`.
*   **Optimización:** Para un videojuego, la optimización es clave. Asegúrese de que sus modelos 3D (especialmente la esfera de la Tierra) tengan un nivel de detalle (LOD) apropiado y que las texturas estén comprimidas correctamente.

Con estos pasos, su proyecto Unity debería tener un sistema robusto y visualmente atractivo para la simulación planetaria con tiempo e iluminación realistas.
