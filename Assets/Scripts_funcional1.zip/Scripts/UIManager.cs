using UnityEngine;

public class UIManager : MonoBehaviour
{
    [Header("Panel (opcional)")]
    public RectTransform uiHubPanel;

    // ── Styles ────────────────────────────────────────────────────────────────
    private GUIStyle _btnStyle;
    private GUIStyle _btnActiveStyle;
    private GUIStyle _labelStyle;
    private GUIStyle _coordStyle;
    private GUIStyle _smallStyle;
    private GUIStyle _warningStyle;
    private GUIStyle _searchStyle;
    private bool     _stylesReady;

    // ── Hover coords ──────────────────────────────────────────────────────────
    private Camera               _cam;
    private MapCameraController  _camController;
    private DaylightVerifier     _daylightVerifier;
    private string  _coordText = "";
    private bool    _hovering;
    private Vector3 _lastMousePos = Vector3.negativeInfinity;

    // ── Button layout ─────────────────────────────────────────────────────────
    private static readonly string[] BTN_LABELS  = { "PAUSA", "x1", "x10", "x100", "x1000" };
    private const float BTN_H  = 32f;
    private const float BTN_W0 = 80f;   // PAUSA
    private const float BTN_W1 = 58f;   // speeds
    private const float GAP    = 4f;
    private const float TOP    = 8f;

    void Start()
    {
        _cam              = Camera.main;
        _camController    = Object.FindAnyObjectByType<MapCameraController>();
        _daylightVerifier = Object.FindAnyObjectByType<DaylightVerifier>();
        CenterUIHubPanel();
    }

    void Update()
    {
        UpdateHoverCoords();
    }

    // ── Mouse → lat/lon ───────────────────────────────────────────────────────
    private void UpdateHoverCoords()
    {
        if (_cam == null || WorldMap.Instance == null) { _hovering = false; return; }

        Vector3 mousePos = Input.mousePosition;
        if (mousePos == _lastMousePos) return;
        _lastMousePos = mousePos;

        Ray ray = _cam.ScreenPointToRay(mousePos);

        Vector3 earthCenter = WorldMap.Instance.transform.position;
        float   earthRadius = WorldMap.Instance.earthRadius;

        if (RaySphere(ray, earthCenter, earthRadius, out Vector3 hit))
        {
            // Transform hit to Earth's local space (accounts for Earth rotation)
            Vector3 local = WorldMap.Instance.transform.InverseTransformPoint(hit);
            Vector3 dir   = local.normalized;

            float lat = Mathf.Asin(Mathf.Clamp(dir.y, -1f, 1f)) * Mathf.Rad2Deg;
            float lon = Mathf.Atan2(dir.z, dir.x) * Mathf.Rad2Deg;

            _coordText = $"Lat: {lat:F2}°   Lon: {lon:F2}°";
            _hovering  = true;
        }
        else
        {
            _hovering = false;
        }
    }

    // Analytical ray-sphere intersection — does not depend on colliders
    private static bool RaySphere(Ray ray, Vector3 center, float radius, out Vector3 hitPoint)
    {
        hitPoint = Vector3.zero;
        Vector3 oc = ray.origin - center;
        float   b  = Vector3.Dot(oc, ray.direction);
        float   c  = Vector3.Dot(oc, oc) - radius * radius;
        float   d  = b * b - c;
        if (d < 0f) return false;
        float t = -b - Mathf.Sqrt(d);
        if (t < 0f) t = -b + Mathf.Sqrt(d);
        if (t < 0f) return false;
        hitPoint = ray.origin + t * ray.direction;
        return true;
    }

    // ── OnGUI ─────────────────────────────────────────────────────────────────
    void OnGUI()
    {
        EnsureStyles();

        if (TimeManager.Instance == null) return;

        DrawSpeedButtons();
        DrawDateTime();
        //DrawDaylightInfo();
        DrawCityNavigationInfo();
        DrawSearchBar();
        DrawCoords();
        DrawLockButton();
    }

    private void DrawSpeedButtons()
    {
        // Total width of all buttons
        float totalW = BTN_W0 + 4f * BTN_W1 + 4f * GAP;
        float startX = (Screen.width - totalW) * 0.5f;
        float x      = startX;

        for (int i = 0; i < BTN_LABELS.Length; i++)
        {
            float w    = i == 0 ? BTN_W0 : BTN_W1;
            var   rect = new Rect(x, TOP, w, BTN_H);
            bool  active = TimeManager.Instance.CurrentSpeedIndex == i;

            if (GUI.Button(rect, BTN_LABELS[i], active ? _btnActiveStyle : _btnStyle))
                TimeManager.Instance.SetSpeedIndex(i);

            x += w + GAP;
        }
    }

    private void DrawDateTime()
    {
        string text = TimeManager.Instance.CurrentLocalTime.ToString("dd/MM/yyyy   HH:mm:ss") + "  BUE";
        float  w    = 320f;
        float  y    = TOP + BTN_H + 4f;
        GUI.Label(new Rect((Screen.width - w) * 0.5f, y, w, 24f), text, _labelStyle);
    }

    private void DrawDaylightInfo()
    {
        if (_daylightVerifier == null) return;
        
        float y = TOP + BTN_H * 2 + 12f;
        float w = 400f;
        float x = (Screen.width - w) * 0.5f;
        
        // Tasa de cumplimiento
        float compliance = _daylightVerifier.GetComplianceRate();
        Color complianceColor = compliance >= 90f ? Color.green : 
                                compliance >= 70f ? Color.yellow : Color.red;
        
        string complianceText = $"✓ Cumplimiento luz solar: {compliance:F1}%";
        
        var complianceStyle = new GUIStyle(_labelStyle);
        complianceStyle.normal.textColor = complianceColor;
        
        GUI.Label(new Rect(x, y, w, 20f), complianceText, complianceStyle);
        
        // Última violación si existe
        if (_daylightVerifier.violations.Count > 0)
        {
            y += 20f;
            var lastViolation = _daylightVerifier.violations[_daylightVerifier.violations.Count - 1];
            string violationText = $"⚠ {lastViolation.cityName}: esperado {lastViolation.expectedHours}h, " +
                                  $"real {lastViolation.actualHours:F1}h (diff {lastViolation.difference:F1}h)";
            
            GUI.Label(new Rect(x, y, w, 18f), violationText, _warningStyle);
        }
        
        // Total de violaciones
        if (_daylightVerifier.violations.Count > 0)
        {
            y += 18f;
            string totalText = $"Total violaciones: {_daylightVerifier.violations.Count}";
            GUI.Label(new Rect(x, y, w, 18f), totalText, _smallStyle);
        }
    }

    private void DrawCityNavigationInfo()
    {
        if (_camController == null) return;
        
        float w = 350f;
        float y = Screen.height - 100f;
        float x = (Screen.width - w) * 0.5f;
        
        string navText = $"{_camController.CurrentCityName} ";
        
        GUI.Label(new Rect(x, y, w, 22f), navText, _labelStyle);
        
        // Instrucciones de navegación
        y += 22f;
        string helpText = "↑↓: navegar ciudades | F: buscar | R: ciudad inicial: Buenos Aires";
        GUI.Label(new Rect(x, y, w, 18f), helpText, _smallStyle);
    }

    private void DrawSearchBar()
    {
        if (_camController == null || !_camController.IsTypingCityName) return;
        
        float w = 300f;
        float h = 30f;
        float x = (Screen.width - w) * 0.5f;
        float y = Screen.height * 0.5f - h * 0.5f;
        
        // Fondo semitransparente
        GUI.Box(new Rect(x - 10, y - 40, w + 20, h + 50), "Buscar Ciudad", _searchStyle);
        
        // Campo de búsqueda
        GUI.SetNextControlName("CitySearch");
        string searchText = GUI.TextField(new Rect(x, y, w, h), _camController.CitySearchString);
        
        // Instrucciones
        GUI.Label(new Rect(x, y + h + 5, w, 20f), "Escribe y presiona Enter | Esc para cancelar", _smallStyle);
    }

    private void DrawCoords()
    {
        float zoom     = _camController != null ? _camController.ZoomPercent : 0f;
        float lineH    = 22f;
        float rows     = _hovering ? 2f : 1f;
        float w        = 280f;
        float h        = lineH * rows + 4f;
        float x        = 10f;
        float y        = Screen.height - h - 10f;

        GUI.Box(new Rect(x - 4, y - 2, w + 8, h + 4), GUIContent.none, _coordBoxStyle);
        GUI.Label(new Rect(x, y, w, lineH), $"Zoom: {zoom:F0}%", _coordStyle);
        if (_hovering)
        {
            GUI.Label(new Rect(x, y + lineH, w, lineH), _coordText, _coordStyle);
            
            // Mostrar horas de luz si hay una ciudad seleccionada
            if (_camController != null && !string.IsNullOrEmpty(_camController.CurrentCityName))
            {
                GUI.Label(new Rect(x, y + lineH * 2, w, lineH), 
                         $"Ciudad: {_camController.CurrentCityName}", _smallStyle);
            }
        }
    }

    // ── Styles (must be created inside OnGUI) ─────────────────────────────────
    private GUIStyle _coordBoxStyle;

    private void EnsureStyles()
    {
        if (_stylesReady) return;
        _stylesReady = true;

        _btnStyle = new GUIStyle(GUI.skin.button)
        {
            fontSize  = 13,
            fontStyle = FontStyle.Bold,
        };
        _btnStyle.normal.textColor  = Color.white;
        _btnStyle.hover.textColor   = Color.yellow;

        _btnActiveStyle = new GUIStyle(_btnStyle);
        _btnActiveStyle.normal.background = MakeTex(2, 2, new Color(0.1f, 0.5f, 0.1f, 0.95f));
        _btnActiveStyle.normal.textColor  = Color.yellow;
        _btnActiveStyle.hover.textColor   = Color.yellow;

        _labelStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize  = 14,
            fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleCenter,
        };
        _labelStyle.normal.textColor = Color.white;

        _coordStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize  = 13,
            fontStyle = FontStyle.Bold,
        };
        _coordStyle.normal.textColor = Color.white;

        _smallStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize  = 11,
            fontStyle = FontStyle.Normal,
            alignment = TextAnchor.MiddleCenter,
        };
        _smallStyle.normal.textColor = new Color(0.7f, 0.7f, 0.7f);

        _warningStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize  = 11,
            fontStyle = FontStyle.Normal,
            alignment = TextAnchor.MiddleCenter,
        };
        _warningStyle.normal.textColor = new Color(1f, 0.6f, 0.2f);

        _searchStyle = new GUIStyle(GUI.skin.box)
        {
            fontSize = 14,
            fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleCenter,
        };
        _searchStyle.normal.textColor = Color.white;
        _searchStyle.normal.background = MakeTex(2, 2, new Color(0f, 0f, 0f, 0.85f));

        _coordBoxStyle = new GUIStyle(GUI.skin.box);
        _coordBoxStyle.normal.background = MakeTex(2, 2, new Color(0f, 0f, 0f, 0.55f));
    }

    private static Texture2D MakeTex(int w, int h, Color col)
    {
        var pix = new Color[w * h];
        for (int i = 0; i < pix.Length; i++) pix[i] = col;
        var t = new Texture2D(w, h);
        t.SetPixels(pix); t.Apply();
        return t;
    }

    public void CenterUIHubPanel()
    {
        if (uiHubPanel == null) return;
        uiHubPanel.anchorMin        = new Vector2(0.5f, 1f);
        uiHubPanel.anchorMax        = new Vector2(0.5f, 1f);
        uiHubPanel.pivot            = new Vector2(0.5f, 1f);
        uiHubPanel.anchoredPosition = Vector2.zero;
    }

    private void DrawLockButton()
    {
        if (_camController == null) return;
        bool locked = _camController.IsManuallyLocked;
        float w = 75f;
        float x = Screen.width - w - 10f;
        if (GUI.Button(new Rect(x, TOP, w, BTN_H), "FIJAR", locked ? _btnActiveStyle : _btnStyle))
            _camController.LockToCurrentPosition();
    }
}